<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">

<#if package?? && package != "">
package ${package};

<#if>
/**
 * @author ${user}
 * Título: Ejercicio 
 * @version ${versionPorDefecto}
 */
//

// Importación de librerías

public class ${name} {

        // Declaración de variables
        // Entrada de datos
        // Salida de datos
        // Operativa
        // Constantes
        // Inicialización        
        // Creación de objetos
        
        // Entrada de datos y resolución del programa

        
        // Salida de datos


    } // fin de main
    
} // fin de la clase ${name}

