/**
 * @author Jose Manuel Sabarís
 * Título: Ejercicio 
 * @version 1.0 
 */
//

// Importación de librerías

public class ${name} {

    public static void main(String[] args) {

        // Declaración de variables
        // Entrada de datos
        // Salida de datos
        // Operativa
        // Constantes
        // Inicialización

        // Creación de objetos
        
        // Entrada de datos y resolución del programa

        
        // Salida de datos


    } // fin de main
    
} // fin de la clase ${name}



